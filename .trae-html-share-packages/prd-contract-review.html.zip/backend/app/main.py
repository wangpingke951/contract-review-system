"""
backend/app/main.py — FastAPI 入口

Phase 2 交付物：
- FastAPI app 创建 + CORS 中间件 + 请求日志
- 全局异常处理器注册
- /api/health 健康检查端点
- /api/auth/* 占位路由（登录/注册/me）
- 启动时自动建表（从 models 导入各 ORM，然后 Base.metadata.create_all）

⚠️ 关键：models 导入是"为了触发各 model 文件的类定义被执行"，
但 models/__init__.py 只导出 Base，所以这里显式 import 每个 model 文件，
否则 Base.metadata 里没有任何表定义，create_all() 会是空操作。
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.core.database import Base, engine
from app.core.exceptions import register_exception_handlers

settings = get_settings()
logger = logging.getLogger("app")


# ——— 导入所有 ORM model（注册到 Base.metadata）———
# 每个 import 必须在独立文件里，且 models/__init__.py 不聚合导入
import app.models.user          # noqa: F401
import app.models.contract      # noqa: F401
import app.models.review        # noqa: F401
import app.models.conversation  # noqa: F401
import app.models.category      # noqa: F401


# ——— lifespan（启动/关闭钩子）———
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    启动时：建表 + 初始化默认管理员用户
    关闭时：关闭数据库连接池
    """
    # 启动
    logger.info("🚀 启动 FastAPI app ...")
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("✅ 数据库表创建完成（或已存在）")
    except Exception as e:
        logger.warning(f"⚠️ 建表失败（MySQL 可能未就绪）: {e}")

    yield

    # 关闭
    await engine.dispose()
    logger.info("👋 FastAPI app 关闭，数据库连接池已释放")


# ——— FastAPI app 实例 ———
app = FastAPI(
    title="合同智能审查系统 API",
    version="1.0.0",
    description="MVP：RAG + 多模态解析 + 对话追问的一体化合同审查平台",
    lifespan=lifespan,
)


# ——— CORS 中间件（Vite dev server + 生产 Nginx）———
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",      # Vite dev
        "http://127.0.0.1:5173",
        "http://localhost:80",        # 生产 Nginx
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ——— 全局异常处理器 ———
register_exception_handlers(app)


# ——— 请求日志（DEBUG 模式）———
@app.middleware("http")
async def request_logging(request: Request, call_next):
    if settings.DEBUG:
        logger.debug(f"📥 {request.method} {request.url.path}")
    response = await call_next(request)
    if settings.DEBUG:
        logger.debug(f"📤 {response.status_code} {request.url.path}")
    return response


# ——— 路由注册 ———
# Phase 2 有 auth；Phase 4 补 contracts；其他 Phase 补 reviews/chat/admin
from app.routers import auth as auth_router               # noqa: E402
from app.routers import contracts as contracts_router     # noqa: E402

app.include_router(auth_router.router,       prefix="/api/auth",      tags=["认证"])
app.include_router(contracts_router.router,  prefix="/api/contracts", tags=["合同"])


# ——— 健康检查 ———
@app.get("/api/health")
async def health():
    """最基础的健康检查"""
    return {
        "code": 0,
        "data": {
            "status": "ok",
            "version": "1.0.0",
            "database": settings.mysql_dsn.split("@")[-1].split("/")[0],  # 只显示 host:port
        },
        "message": "",
    }


# ——— 简单测试端点 ———
@app.get("/")
async def root():
    return JSONResponse({
        "code": 0,
        "data": {"service": "contract-review-api", "version": "1.0.0"},
        "message": "合同智能审查系统 API 运行中，访问 /api/health 检查状态",
    })
