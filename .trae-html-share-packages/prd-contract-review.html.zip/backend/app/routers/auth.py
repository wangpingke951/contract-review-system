"""
app/routers/auth.py — 认证相关路由

Phase 2 提供最小可用的登录/注册/me 接口，业务逻辑留 Phase 完整实现：
- POST /api/auth/login  → 返回 JWT（占位：先查数据库，查不到返回 401）
- POST /api/auth/register → 注册普通用户（占位）
- GET  /api/auth/me     → 返回当前用户信息（需 JWT）
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from app.core.dependencies import get_current_user
from app.core.security import (
    UserRole,
    create_access_token,
    verify_password,
    hash_password,
    TokenPayload,
)

router = APIRouter()


# —— Phase 2 临时 import（验证能 import 就行）——
# from app.core.database import get_db
# from sqlalchemy import select
# from app.models.user import User
# 上面这些业务代码 Phase 补齐

# —— 请求/响应 schema ——
class LoginRequest(BaseModel):
    username: str
    password: str


class RegisterRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str


class UserResponse(BaseModel):
    id: int
    username: str
    role: str


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest):
    """
    用户登录（Phase 2 骨架：先返回 mock token，Phase 补真实 DB 查询）
    """
    # Phase 完整实现：从 DB 查 User → verify_password → create_access_token
    # 骨架版：直接返回 mock token，方便前端联调
    token = create_access_token(
        user_id=1,
        username=body.username,
        role=UserRole.USER,
    )
    return TokenResponse(access_token=token, role="user")


@router.post("/login/admin", response_model=TokenResponse)
async def login_admin(body: LoginRequest):
    """管理员登录（骨架版：直接返回 admin role token）"""
    token = create_access_token(
        user_id=1,
        username=body.username,
        role=UserRole.ADMIN,
    )
    return TokenResponse(access_token=token, role="admin")


@router.post("/register", response_model=dict)
async def register(body: RegisterRequest):
    """注册（骨架版：占位）"""
    # Phase 完整实现：查重 → hash_password → insert → 返回 user_id
    return {"code": 0, "data": {"user_id": 1}, "message": "注册成功（骨架版）"}


@router.get("/me", response_model=UserResponse)
async def get_me(current: TokenPayload = Depends(get_current_user)):
    """获取当前登录用户（需 JWT）"""
    return UserResponse(
        id=current.user_id,
        username=current.username,
        role=current.role.value,
    )
