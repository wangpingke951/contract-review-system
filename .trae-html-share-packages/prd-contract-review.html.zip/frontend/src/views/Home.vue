<!-- frontend/src/views/Home.vue — 首页 / 合同上传（Phase 3 骨架） -->
<template>
  <div class="home">
    <el-card class="upload-card">
      <template #header>
        <div class="card-header">
          <el-icon :size="18"><UploadFilled /></el-icon>
          <span>上传合同并发起审查</span>
        </div>
      </template>

      <el-upload
        class="uploader"
        drag
        :auto-upload="false"
        :limit="5"
        :file-list="fileList"
        accept=".pdf,.docx,.png,.jpg,.jpeg"
        :on-change="handleFileChange"
        :on-remove="handleFileRemove"
      >
        <el-icon :size="40" color="#3b82f6"><UploadFilled /></el-icon>
        <div class="el-upload__text">
          点击或拖拽上传 &nbsp;
          <em>.pdf / .docx / .png / .jpg</em>
        </div>
        <template #tip>
          <div class="el-upload__tip">单个文件不超过 50MB，支持批量上传最多 5 个</div>
        </template>
      </el-upload>

      <div class="actions">
        <el-button type="primary" :disabled="fileList.length === 0" @click="handleStartReview">
          <el-icon><VideoPlay /></el-icon> 开始审查
        </el-button>
      </div>
    </el-card>

    <el-card class="history-card">
      <template #header>
        <div class="card-header">
          <el-icon :size="18"><Clock /></el-icon>
          <span>历史合同（Phase 4 补真实数据）</span>
        </div>
      </template>
      <el-empty description="暂无历史合同">
        <el-button type="primary" @click="$refs.uploaderInput.click()">上传第一份合同</el-button>
      </el-empty>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'

const fileList = ref([])

function handleFileChange(file, list) {
  // Phase 4 补完整校验（文件类型 + 大小 + 中文检测）
  fileList.value = list
}

function handleFileRemove(file, list) {
  fileList.value = list
}

function handleStartReview() {
  if (fileList.value.length === 0) return
  ElMessage.info(`将上传 ${fileList.value.length} 个文件 — Phase 4 补真实上传接口`)
}
</script>

<style scoped>
.home { display: grid; grid-template-columns: 1fr; gap: 20px; }
.card-header { display: flex; align-items: center; gap: 8px; font-weight: 700; }
.upload-card .uploader { width: 100%; }
.actions { margin-top: 20px; text-align: center; }
</style>
