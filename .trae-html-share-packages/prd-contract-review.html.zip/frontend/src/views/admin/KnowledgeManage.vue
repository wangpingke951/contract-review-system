<!-- frontend/src/views/admin/KnowledgeManage.vue — 知识库管理（Phase 3 占位，Phase 8 补完整） -->
<template>
  <el-card>
    <template #header>
      <div class="card-header">
        <el-icon :size="18"><FolderOpened /></el-icon>
        <span>知识库管理 — Phase 8 补：上传 / 列表 / 删除 + 切块状态</span>
      </div>
    </template>
    <el-empty description="Phase 8 实现完整知识库 CRUD">
      <el-tag type="info">待实现</el-tag>
    </el-empty>
  </el-card>
</template>

<style scoped>
.card-header { display: flex; align-items: center; gap: 8px; font-weight: 700; }
</style>
