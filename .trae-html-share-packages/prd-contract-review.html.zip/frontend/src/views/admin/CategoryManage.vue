<!-- frontend/src/views/admin/CategoryManage.vue — 风险类别管理（Phase 3 占位，Phase 8 补完整） -->
<template>
  <el-card>
    <template #header>
      <div class="card-header">
        <el-icon :size="18"><Tag /></el-icon>
        <span>风险类别管理 — Phase 8 补：新增 / 删除 + 至少保留 1 个的约束</span>
      </div>
    </template>
    <el-empty description="Phase 8 实现完整类别管理">
      <el-tag type="info">待实现</el-tag>
    </el-empty>
  </el-card>
</template>

<style scoped>
.card-header { display: flex; align-items: center; gap: 8px; font-weight: 700; }
</style>
