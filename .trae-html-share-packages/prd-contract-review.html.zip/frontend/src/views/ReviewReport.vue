<!-- frontend/src/views/ReviewReport.vue — 审查报告页（Phase 3 占位，Phase 6 补三栏布局） -->
<template>
  <el-card>
    <el-empty description="审查报告页 — Phase 6 实现完整三栏布局">
      <el-button @click="$router.back()">返回首页</el-button>
    </el-empty>
  </el-card>
</template>

<script setup>
// Phase 6 补：左侧章节导航 + 中间合同原文高亮 + 右侧风险项列表 + 底部/右侧对话面板
</script>
